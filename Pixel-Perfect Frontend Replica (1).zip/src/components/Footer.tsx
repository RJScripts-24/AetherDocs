import { ScrollFadeIn } from './ScrollFadeIn';

interface FooterProps {
  isDarkMode: boolean;
}

export function Footer({ isDarkMode }: FooterProps) {
  return (
    <footer className="mx-auto px-4 md:px-6 py-8 md:py-12 text-center" style={{ maxWidth: '1440px' }}>
      <ScrollFadeIn direction="none" delay={0}>
        <p 
          className="text-sm italic"
          style={{ 
            color: isDarkMode ? '#DCD7C9' : '#2C3930',
            opacity: 0.7
          }}
        >
          Meanwhile,{' '}
          <span style={{ fontStyle: 'italic' }}>the final year at Auto-deep</span>
          . A Storr™ project.
        </p>
      </ScrollFadeIn>
    </footer>
  );
}