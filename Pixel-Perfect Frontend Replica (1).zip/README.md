
  # Pixel-Perfect Frontend Replica

  This is a code bundle for Pixel-Perfect Frontend Replica. The original project is available at https://www.figma.com/design/oy0EhqAxcVXX91bcUI5Elk/Pixel-Perfect-Frontend-Replica.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  